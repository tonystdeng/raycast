LD_LIBRARY_PATH=bin ./bin/mainExecutable $*
